import 'package:flutter/material.dart';
import '../models/comment.dart';

class CommentWidget extends StatelessWidget {
  final Comment comment;

  CommentWidget({required this.comment});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.symmetric(vertical: 4),
      child: Padding(
        padding: EdgeInsets.all(8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              comment.by,
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 4),
            Text(comment.text),
            // Réponses imbriquées (optionnel)
            if (comment.replies.isNotEmpty)
              ...comment.replies.map((reply) => Padding(
                padding: EdgeInsets.only(left: 16),
                child: CommentWidget(comment: reply),
              )),
          ],
        ),
      ),
    );
  }
}