import 'package:flutter/material.dart';
import '../models/comment_model.dart';
import '../services/api_service.dart';

class CommentWidget extends StatefulWidget {
  final int commentId;
  final int depth;

  const CommentWidget({
    super.key,
    required this.commentId,
    this.depth = 0,
  });

  @override
  State<CommentWidget> createState() => _CommentWidgetState();
}

class _CommentWidgetState extends State<CommentWidget>
    with SingleTickerProviderStateMixin {
  Comment? comment;
  bool isLoading = true;
  bool showReplies = false;
  bool isExpandedText = false;

  late final AnimationController _controller;
  late final Animation<double> _fadeIn;

  @override
  void initState() {
    super.initState();
    _controller =
        AnimationController(duration: const Duration(milliseconds: 400), vsync: this);
    _fadeIn = CurvedAnimation(parent: _controller, curve: Curves.easeIn);
    loadComment();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> loadComment() async {
    try {
      final fetchedComment = await ApiService.fetchComment(widget.commentId);
      setState(() {
        comment = fetchedComment;
        isLoading = false;
      });
      _controller.forward();
    } catch (e) {
      print('Erreur commentaire: $e');
      setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return Padding(
        padding: EdgeInsets.only(left: widget.depth * 12.0, top: 8, bottom: 8),
        child: const CircularProgressIndicator(strokeWidth: 2),
      );
    }

    if (comment == null || comment!.text == null) {
      return const SizedBox();
    }

    return Padding(
      padding: EdgeInsets.only(
        left: widget.depth * 16.0,
        right: 8,
        top: 8,
        bottom: 8,
      ),
      child: FadeTransition(
        opacity: _fadeIn,
        child: Container(
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.secondary.withOpacity(0.3),
            borderRadius: BorderRadius.circular(12),
          ),
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Auteur
              Row(
                children: [
                  const Icon(Icons.person, size: 18, color: Colors.grey),
                  const SizedBox(width: 4),
                  Text(
                    comment!.author ?? 'Anonyme',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Theme.of(context).primaryColor,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 4),

              // Texte avec Afficher plus
              LayoutBuilder(
                builder: (context, constraints) {
                  final cleanText = _stripHtml(comment!.text!);
                  final shouldTruncate = cleanText.length > 180;

                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        cleanText,
                        maxLines: isExpandedText ? null : 3,
                        overflow: isExpandedText
                            ? TextOverflow.visible
                            : TextOverflow.ellipsis,
                        style: Theme.of(context).textTheme.bodyMedium,
                      ),
                      if (shouldTruncate)
                        TextButton(
                          onPressed: () {
                            setState(() {
                              isExpandedText = !isExpandedText;
                            });
                          },
                          style: TextButton.styleFrom(padding: EdgeInsets.zero),
                          child: Text(
                            isExpandedText
                                ? 'Afficher moins'
                                : 'Afficher plus',
                            style: TextStyle(
                              color: Theme.of(context).primaryColor,
                              fontWeight: FontWeight.w500,
                            ),
                          ),
                        ),
                    ],
                  );
                },
              ),

              const SizedBox(height: 8),

              // Bouton voir les réponses
              if ((comment!.childrenIds?.isNotEmpty ?? false))
                GestureDetector(
                  onTap: () {
                    setState(() {
                      showReplies = !showReplies;
                    });
                  },
                  child: Row(
                    children: [
                      Icon(
                        showReplies
                            ? Icons.expand_less
                            : Icons.expand_more,
                        size: 18,
                        color: Theme.of(context).primaryColor,
                      ),
                      const SizedBox(width: 4),
                      const Icon(Icons.reply, size: 18, color: Colors.grey),
                      const SizedBox(width: 4),
                      Text(
                        showReplies
                            ? 'Cacher les réponses'
                            : 'Voir les réponses',
                        style: TextStyle(
                          color: Theme.of(context).primaryColor,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),

              const SizedBox(height: 8),

              // Réponses imbriquées
              if (showReplies)
                ...comment!.childrenIds!
                    .map((id) =>
                        CommentWidget(commentId: id, depth: widget.depth + 1))
                    .toList(),
            ],
          ),
        ),
      ),
    );
  }

  String _stripHtml(String htmlText) {
    return htmlText
        .replaceAll(RegExp(r'<[^>]*>'), '')
        .replaceAll('&quot;', '"')
        .replaceAll('&#x27;', "'")
        .replaceAll('&gt;', '>')
        .replaceAll('&lt;', '<');
  }
}