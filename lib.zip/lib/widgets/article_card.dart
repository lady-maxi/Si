import 'package:flutter/material.dart';
import '../models/article.dart';
import '../screens/article_detail_screen.dart';
class ArticleCard extends StatelessWidget {
  final Article article;

  const ArticleCard({Key? key, required this.article}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => ArticleDetailScreen(article: article),
            ),
          );
        },
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Titre
              Text(
                article.title,
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w600,
                  fontFamily: 'OpenSans',
                  color: Colors.grey[800],
                ),
              ),
              SizedBox(height: 12),
              
              // Métadonnées
              Row(
                children: [
                  Row(
                    children: [
                      Icon(Icons.person_outline, size: 16, color: Colors.blue[400]),
                      SizedBox(width: 4),
                      Text(
                        article.by ?? "Anonyme",
                        style: TextStyle(
                          fontFamily: 'OpenSans',
                          color: Colors.grey[600],
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(width: 16),
                  Row(
                    children: [
                      Icon(Icons.comment_outlined, size: 16, color: Colors.blue[400]),
                      SizedBox(width: 4),
                      Text(
                        '${article.commentCount ?? 0}',
                        style: TextStyle(
                          fontFamily: 'OpenSans',
                          color: Colors.grey[600],
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                  Spacer(),
                  Icon(Icons.arrow_forward_ios, size: 16, color: Colors.blue[400]),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}