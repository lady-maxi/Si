import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/article_model.dart';
import '../models/comment_model.dart';

class ApiService {
  static const String baseUrl = 'https://hacker-news.firebaseio.com/v0';

  static Future<List<int>> fetchTopStoryIds() async {
    final response = await http.get(Uri.parse('$baseUrl/topstories.json'));
    if (response.statusCode == 200) {
      List<dynamic> ids = json.decode(response.body);
      return ids.cast<int>().take(20).toList(); // On prend les 20 premiers
    } else {
      throw Exception('Échec du chargement des IDs');
    }
  }

  static Future<Article> fetchArticle(int id) async {
    final response = await http.get(Uri.parse('$baseUrl/item/$id.json'));
    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      return Article.fromJson(data);
    } else {
      throw Exception('Échec du chargement de l’article');
    }
  }

  static Future<Comment> fetchComment(int id) async {
    final response = await http.get(
      Uri.parse('https://hacker-news.firebaseio.com/v0/item/$id.json?print=pretty'),
    );
    if (response.statusCode == 200) {
      final json = jsonDecode(response.body);
      return Comment.fromJson(json);
    } else {
      throw Exception('Erreur lors du chargement du commentaire');
    }
  }
}