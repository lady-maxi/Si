import 'dart:async';
import 'package:path/path.dart';
import 'package:http/http.dart' as http;
import 'package:sqflite/sqflite.dart';
import '../models/article_model.dart';

class DBService {
  static Database? _database;

  static Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB();
    return _database!;
  }

  static Future<Database> _initDB() async {
    final path = join(await getDatabasesPath(), 'favorites.db');
    return await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) {
        return db.execute('''
          CREATE TABLE favorites (
            id INTEGER PRIMARY KEY,
            title TEXT,
            author TEXT,
            url TEXT,
            commentCount INTEGER
          )
        ''');
      },
    );
  }


  static Future<void> cleanUpNonFavorites() async {
  final db = await database;
  final List<Map<String, dynamic>> saved = await db.query('favorites');
  for (var map in saved) {
    final int id = map['id'];
    final exists = await _checkIfExistsOnAPI(id);
    if (!exists) {
      await db.delete('favorites', where: 'id = ?', whereArgs: [id]);
    }
  }
}

static Future<bool> _checkIfExistsOnAPI(int id) async {
  final response = await http.get(Uri.parse('https://hacker-news.firebaseio.com/v0/item/$id.json'));
  return response.statusCode == 200 && response.body != 'null';
}



  static Future<void> insertFavorite(Article article) async {
    final db = await database;
    await db.insert(
      'favorites',
      {
        'id': article.id,
        'title': article.title,
        'author': article.author,
        'url': article.url,
        'commentCount': article.commentCount
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  static Future<void> removeFavorite(int id) async {
    final db = await database;
    await db.delete('favorites', where: 'id = ?', whereArgs: [id]);
  }

  static Future<List<Article>> getFavorites() async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query('favorites');
    return List.generate(maps.length, (i) {
      return Article(
        id: maps[i]['id'],
        title: maps[i]['title'],
        author: maps[i]['author'],
        url: maps[i]['url'],
        commentCount: maps[i]['commentCount'],
        commentIds: [], // On ne stocke pas les commentaires ici
      );
    });
  }

  static Future<bool> isFavorite(int id) async {
    final db = await database;
    final List<Map<String, dynamic>> maps =
        await db.query('favorites', where: 'id = ?', whereArgs: [id]);
    return maps.isNotEmpty;
  }
}