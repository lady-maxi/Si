import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/article.dart';
import '../models/comment.dart';
import '../providers/news_provider.dart';
import '../widgets/comment_widget.dart';

class ArticleDetailScreen extends StatefulWidget {
  final Article article;

  const ArticleDetailScreen({Key? key, required this.article}) : super(key: key);

  @override
  _ArticleDetailScreenState createState() => _ArticleDetailScreenState();
}

class _ArticleDetailScreenState extends State<ArticleDetailScreen> {
  Future<List<Comment>>? _commentsFuture;

  @override
  void initState() {
    super.initState();
    _loadComments();
  }

  void _loadComments() {
    final provider = Provider.of<NewsProvider>(context, listen: false);
    _commentsFuture = provider.fetchComments(widget.article.kids ?? []);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50], // Fond légèrement gris
      appBar: AppBar(
        title: Text(
          'Détails',
          style: TextStyle(
            fontFamily: 'OpenSans', // Police personnalisée (à déclarer dans pubspec.yaml)
            fontWeight: FontWeight.w600,
            color: Colors.white,
          ),
        ),
        backgroundColor: Colors.blue[600], // AppBar bleue douce
        elevation: 0,
        iconTheme: IconThemeData(color: Colors.white),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh, color: Colors.white),
            onPressed: _loadComments,
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Carte de l'article
            Card(
              elevation: 2,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: Padding(
                padding: EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Titre
                    Text(
                      widget.article.title,
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'OpenSans',
                        color: Colors.grey[800],
                      ),
                    ),
                    SizedBox(height: 12),

                    // Métadonnées avec icônes
                    Row(
                      children: [
                        Icon(Icons.person_outline, size: 18, color: Colors.blue[400]),
                        SizedBox(width: 4),
                        Text(
                          widget.article.by ?? "Anonyme",
                          style: TextStyle(
                            color: Colors.grey[600],
                            fontFamily: 'OpenSans',
                          ),
                        ),
                        SizedBox(width: 16),
                        Icon(Icons.comment_outlined, size: 18, color: Colors.blue[400]),
                        SizedBox(width: 4),
                        Text(
                          '${widget.article.commentCount ?? 0}',
                          style: TextStyle(
                            color: Colors.grey[600],
                            fontFamily: 'OpenSans',
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 24),

            // Section Commentaires
            Text(
              'Commentaires',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w600,
                fontFamily: 'OpenSans',
                color: Colors.blue[700],
              ),
            ),
            Divider(color: Colors.blue[100], height: 24),

            // Liste des commentaires
            FutureBuilder<List<Comment>>(
              future: _commentsFuture,
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return Center(
                    child: CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation<Color>(Colors.blue[400]!),
                    ),
                  );
                } else if (snapshot.hasError) {
                  return Column(
                    children: [
                      Icon(Icons.error_outline, color: Colors.orange[400], size: 40),
                      SizedBox(height: 8),
                      Text(
                        "Oups, une erreur est survenue",
                        style: TextStyle(color: Colors.grey[600]),
                      ),
                      SizedBox(height: 12),
                      ElevatedButton(
                        onPressed: _loadComments,
                        child: Text("Réessayer"),
                        style: ElevatedButton.styleFrom(
                          surfaceTintColor: Colors.blue[400],
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                        ),
                      ),
                    ],
                  );
                } else if (snapshot.data == null || snapshot.data!.isEmpty) {
                  return Column(
                    children: [
                      Icon(Icons.forum_outlined, color: Colors.grey[400], size: 40),
                      SizedBox(height: 8),
                      Text(
                        "Aucun commentaire pour cet article",
                        style: TextStyle(color: Colors.grey[500]),
                      ),
                    ],
                  );
                } else {
                  return ListView.separated(
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    itemCount: snapshot.data!.length,
                    separatorBuilder: (context, index) => Divider(height: 16, color: Colors.transparent),
                    itemBuilder: (context, index) => CommentWidget(
                      comment: snapshot.data![index],
                    ),
                  );
                }
              },
            ),
          ],
        ),
      ),
    );
  }
}