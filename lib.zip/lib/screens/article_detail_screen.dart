import 'package:flutter/material.dart';
import '../services/db_service.dart';
import '../models/article_model.dart';
import '../widgets/comment_widget.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:url_launcher/url_launcher.dart';


class ArticleDetailScreen extends StatefulWidget {
  final Article article;

  const ArticleDetailScreen({super.key, required this.article});

  @override
  State<ArticleDetailScreen> createState() => _ArticleDetailScreenState();
}

class _ArticleDetailScreenState extends State<ArticleDetailScreen> {
  bool isFavorite = false;

  @override
  void initState() {
    super.initState();
    checkIfFavorite();
  }

  Future<void> checkIfFavorite() async {
    final fav = await DBService.isFavorite(widget.article.id);
    setState(() {
      isFavorite = fav;
    });
  }

  Future<void> toggleFavorite() async {
    if (isFavorite) {
      await DBService.removeFavorite(widget.article.id);
    } else {
      await DBService.insertFavorite(widget.article);
    }
    setState(() {
      isFavorite = !isFavorite;
    });
  }

  @override
  Widget build(BuildContext context) {
    final hasUrl = widget.article.url != null;

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.article.title, maxLines: 1, overflow: TextOverflow.ellipsis),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(
              isFavorite ? Icons.star : Icons.star_border,
              color: Colors.yellow[700],
            ),
            onPressed: toggleFavorite,
          )
        ],
      ),
      body: hasUrl
          ? Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Card(
                    color: Theme.of(context).colorScheme.secondary.withOpacity(0.2),
                    elevation: 3,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              const Icon(Icons.title, color: Colors.grey),
                              const SizedBox(width: 6),
                              Expanded(
                                child: Text(
                                  widget.article.title,
                                  style: Theme.of(context)
                                      .textTheme
                                      .titleLarge
                                      ?.copyWith(fontSize: 14),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          Row(
                            children: [
                              const Icon(Icons.person, size: 14, color: Color.fromARGB(255, 65, 59, 59)),
                              const SizedBox(width: 6),
                              Text(
                                widget.article.author ?? "Inconnu",
                                style: Theme.of(context).textTheme.bodyMedium,
                              ),
                              const SizedBox(width: 16),
                              const Icon(Icons.comment, size: 14, color: Color.fromARGB(255, 65, 59, 59)),
                              const SizedBox(width: 4),
                              Text(
                                '${widget.article.commentCount ?? 0} commentaires',
                                style: Theme.of(context).textTheme.bodyMedium,
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          ElevatedButton.icon(
                            onPressed: () async {
                              final uri = Uri.parse(widget.article.url!);
                              if (await canLaunchUrl(uri)) {
                                await launchUrl(uri, mode: LaunchMode.externalApplication);
                              } else {
                                ScaffoldMessenger.of(context).showSnackBar(
                                  const SnackBar(content: Text("Impossible d’ouvrir le lien")),
                                );
                              }
                            },
                            icon: const Icon(Icons.open_in_browser,size: 14,color: Color.fromARGB(255, 65, 59, 59)),
                            label: const Text("Lire l’article sur le site"),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Theme.of(context).colorScheme.secondary,
                              foregroundColor: Colors.black,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                Expanded(
                  child: ListView(
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    children: [
                      const Divider(),
                      if (widget.article.commentIds != null &&
                          widget.article.commentIds!.isNotEmpty)
                        ...widget.article.commentIds!
                            .map((id) => CommentWidget(commentId: id))
                            .toList()
                      else
                        const Center(child: Text('Aucun commentaire')),
                    ],
                  ),
                ),
              ],
            )
          : Center(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Text(
                  "Aucun lien disponible pour cet article.",
                  style: Theme.of(context).textTheme.bodyLarge,
                ),
              ),
            ),
    );
  }
}