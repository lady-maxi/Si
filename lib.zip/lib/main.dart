import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

import 'services/db_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await DBService.cleanUpNonFavorites(); // nettoyage automatique
  runApp(const HackerNewsApp());
}

class HackerNewsApp extends StatelessWidget {
    const HackerNewsApp({super.key});

    @override
    Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Hacker News Reader',
      theme: ThemeData(
        scaffoldBackgroundColor: const Color(0xFFC9E4CA),
        primaryColor: const Color(0xFF3B6064),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF3B6064),
          foregroundColor: Colors.white,
          elevation: 2,
        ),
        textTheme: const TextTheme(
          bodyLarge: TextStyle(color: Color(0xFF364958)),
          bodyMedium: TextStyle(color: Color(0xFF364958)),
          titleLarge: TextStyle(
            color: Color(0xFF364958),
            fontWeight: FontWeight.bold,
          ),
        ),
        floatingActionButtonTheme: const FloatingActionButtonThemeData(
          backgroundColor: Color(0xFF87BBA2),
        ),
        colorScheme: ColorScheme.fromSwatch().copyWith(
          secondary: const Color(0xFF87BBA2),
        ),
      ),
      home: const HomeScreen(),
    );
  }
}