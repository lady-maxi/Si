import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../models/article.dart';
import 'dart:convert';
import '../models/comment.dart';

class NewsProvider with ChangeNotifier {
  List<Article> _articles = [];
  List<Article> get articles => _articles;

  Future<List<Comment>> fetchComments(List<int> commentIds) async {
    List<Comment> comments = [];
    for (int id in commentIds) {
      final response = await http.get(
        Uri.parse('https://hacker-news.firebaseio.com/v0/item/$id.json'),
      );
      if (response.statusCode == 200) {
        comments.add(Comment.fromJson(json.decode(response.body)));
      }
    }
    return comments;
  }


  Future<void> fetchTopArticles() async {
    try {
      // 1. Récupère les IDs des articles populaires
      final response = await http.get(
        Uri.parse('https://hacker-news.firebaseio.com/v0/topstories.json'),
      );
      
      if (response.statusCode == 200) {
        List<int> articleIds = List<int>.from(json.decode(response.body).take(20)); // Prend 20 articles max

        // 2. Récupère chaque article individuellement
        _articles = [];
        for (int id in articleIds) {
          final articleResponse = await http.get(
            Uri.parse('https://hacker-news.firebaseio.com/v0/item/$id.json'),
          );
          if (articleResponse.statusCode == 200) {
            _articles.add(Article.fromJson(json.decode(articleResponse.body)));
          }
        }
        notifyListeners(); // Met à jour l'UI
      }
    } catch (e) {
      print("Erreur : $e");
    }
  }
}