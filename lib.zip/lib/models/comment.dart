class Comment {
  final String by;
  final String text;
  final List<Comment> replies; // Pour les réponses imbriquées

  Comment({
    required this.by,
    required this.text,
    this.replies = const [],
  });

  factory Comment.fromJson(Map<String, dynamic> json) {
    return Comment(
      by: json['by'] ?? 'Anonyme',
      text: json['text'] ?? '',
    );
  }
}