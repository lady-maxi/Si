class Article {
  final int id;
  final String title;
  final String? author;
  final String? url;
  final List<dynamic>? commentIds;
  final int? commentCount;

  Article({
    required this.id,
    required this.title,
    this.author,
    this.url,
    this.commentIds,
    this.commentCount,
  });

  factory Article.fromJson(Map<String, dynamic> json) {
    return Article(
      id: json['id'],
      title: json['title'] ?? 'Titre inconnu',
      author: json['by'],
      url: json['url'],
      commentIds: json['kids'],
      commentCount: json['descendants'],
    );
  }
}