class Article {
  final int id;
  final String title;
  final String? by;
  final String? url;
  final int? commentCount;
  final List<int>? kids; // Contient les IDs des commentaires (nom utilisé par l'API HN)

  Article({
    required this.id,
    required this.title,
    this.by,
    this.url,
    this.commentCount,
    this.kids, // Ajout de cette propriété
  });

  factory Article.fromJson(Map<String, dynamic> json) {
    return Article(
      id: json['id'],
      title: json['title'] ?? 'Pas de titre',
      by: json['by'],
      url: json['url'],
      commentCount: json['descendants'] ?? 0, // Nombre total de commentaires
      kids: json['kids'] != null ? List<int>.from(json['kids']) : null, // IDs des commentaires
    );
  }
}