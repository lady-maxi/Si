class Comment {
  final int id;
  final String? author;
  final String? text;
  final List<int>? childrenIds;

  Comment({
    required this.id,
    this.author,
    this.text,
    this.childrenIds,
  });

  factory Comment.fromJson(Map<String, dynamic> json) {
    return Comment(
      id: json['id'],
      author: json['by'],
      text: json['text'],
      childrenIds: (json['kids'] as List?)?.map((e) => e as int).toList(),
    );
  }
}